const Profile = () => {
    return (
        <h1>Xinn chao!</h1>
    );
}
export default Profile;